-- Create databae
CREATE DATABASE estore;

-- Use the created database
USE estore;

-- User table
CREATE TABLE user (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  user_type ENUM('admin', 'customer', 'seller') NOT NULL
);

-- Seller table
CREATE TABLE seller (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(20),
  address VARCHAR(255),
  user_id INT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES user(id)
);

-- Customer table
CREATE TABLE customer (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(20),
  address VARCHAR(255),
  user_id INT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES user(id)
);

-- Products table
CREATE TABLE product (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  stock INT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  seller_id INT NOT NULL,
  FOREIGN KEY (seller_id) REFERENCES seller(id)
);

-- Orders table
CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  order_date DATE NOT NULL,
  FOREIGN KEY (customer_id) REFERENCES user(id),
  FOREIGN KEY (product_id) REFERENCES product(id)
);


-- Inserting data into user table
INSERT INTO user (username, password, user_type) VALUES
('admin', 'admin123', 'admin'),
('seller1', 'seller123', 'seller'),
('seller2', 'seller123', 'seller'),
('customer1', 'customer123', 'customer'),
('customer2', 'customer123', 'customer'),
('1', '1', 'admin');

-- Inserting data into seller table
INSERT INTO seller (name, email, phone, address, user_id) VALUES
('Seller 1', 'seller1@example.com', '1234567890', '123 Main Street', 2),
('Seller 2', 'seller2@example.com', '0987654321', '456 Market Street', 3);

-- Inserting data into customer table
INSERT INTO customer (name, email, phone, address, user_id) VALUES
('Customer 1', 'customer1@example.com', '1112223333', '789 Elm Street', 4),
('Customer 2', 'customer2@example.com', '4445556666', '321 Oak Street', 5);

-- Inserting data into product table
INSERT INTO product (name, description, stock, price, seller_id) VALUES
('Product 1', 'Description for Product 1', 10, 100.00, 1),
('Product 2', 'Description for Product 2', 10, 200.00, 2),
('Product 3', 'Description for Product 3', 10, 300.00, 2),
('Product 4', 'Description for Product 4', 10, 400.00, 1),
('Product 5', 'Description for Product 5', 10, 500.00, 1);

-- Inserting data into orders table
INSERT INTO orders (customer_id, product_id, quantity, price, order_date) VALUES
(1, 1, 2, 200.00, '2022-01-01'),
(2, 3, 1, 300.00, '2022-02-01'),
(2, 2, 3, 600.00, '2022-03-01'),
(3, 4, 1, 400.00, '2022-04-01'),
(4, 5, 2, 1000.00, '2022-05-01');